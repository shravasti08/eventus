//
//  eventusApp.swift
//  eventus
//
//  Created by Shravasti on 28/02/24.
//

import SwiftUI

@main
struct eventusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
